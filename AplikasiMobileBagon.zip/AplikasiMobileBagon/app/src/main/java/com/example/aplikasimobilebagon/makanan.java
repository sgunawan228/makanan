package com.example.aplikasimobilebagon;

public class makanan {
    private String nama;
    private String deskripsi;
    private int harga;
    private String gambar;

    public makanan(String nama, String deskripsi, int harga, String gambar){
        this.nama = nama;
        this.deskripsi = deskripsi;
        this.harga = harga;
        this.gambar = gambar;
    }

    public String getNama(){
        return nama;
    }

    public String getDeskripsi(){
        return deskripsi;
    }

    public int getHarga(){
        return harga;
    }

    public String getGambar(){
        return gambar;
    }
}
